Ela&Chat Android başlanğıc layihəsi (0.1.0)

Bu ZIP hazır APK deyil. Android Studio ilə açılan ilkin Android layihə skeletidir.
Daxilində loqo və işlək vizual prototip var. Hazırda real hesablar, serverdə mesajlaşma,
push bildirişləri, media yükləmə və sinxronizasiya qoşulmayıb.

APK yaratmaq:
1. Android Studio quraşdırın.
2. Bu qovluğu Android Studio-da Open ilə açın.
3. Gradle sinxronizasiyasını tamamlayın.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

Tam onlayn sistem üçün Firebase layihəsi lazımdır:
- Authentication: Phone, Google, Email/Password (Apple üçün ayrıca OAuth konfiqurasiyası)
- Cloud Firestore: istifadəçilər, söhbətlər, mesajlar, qruplar, hekayələr, streak/pet
- Cloud Storage: profil şəkilləri və media
- Firebase Cloud Messaging: bildirişlər

Növbəti addım: Firebase Console-da layihə yaratmaq və Android tətbiqini
com.elachat paket adı ilə əlavə etmək; sonra google-services.json faylını
app/ qovluğuna yerləşdirmək və Firebase SDK-larını qoşmaq.
